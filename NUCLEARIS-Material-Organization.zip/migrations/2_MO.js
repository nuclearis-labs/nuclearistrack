var MO = artifacts.require("./MO.sol");

module.exports = function(deployer) {
  deployer.deploy(MO);
};
